'use client'

import { CSSProperties } from 'react'
import FinancialGoalsPanel from './FinancialGoalsPanel'
import {
  FinancialGoal,
  FinancialGoalAllocationMode,
  FinancialGoalMonthConfig,
  FinancialGoalMonthPriority,
  Transaction,
} from '../lib/budgetPageTypes'

type Props = {
  selectedMonth: string
  goals?: FinancialGoal[]
  goalPriorities?: FinancialGoalMonthPriority[]
  goalMonthConfigs?: FinancialGoalMonthConfig[]
  transactions?: Transaction[]
  budgetStartDate?: string | null
  excludedMonthsSet: Set<string>
  lockedMonthsSet: Set<string>
  getSignedAmountForTransaction: (transaction: Transaction) => number
  onSaveGoal: (input: Omit<FinancialGoal, 'id' | 'profile_id' | 'created_at'>) => Promise<void>
  onDeleteGoal: (goalId: string) => Promise<void>
  onSetGoalStatus: (goalId: string, status: NonNullable<FinancialGoal['status']>, month: string) => Promise<void>
  onSetGoalModeForMonth: (month: string, mode: FinancialGoalAllocationMode) => Promise<void>
  onSaveGoalAllocationsForMonth: (
    month: string,
    allocationsByGoalId: Record<string, number>
  ) => Promise<void>
  onReorderGoalsForMonth: (month: string, orderedGoalIds: string[]) => Promise<void>
  styles: Record<string, CSSProperties>
}

export default function FinancialGoalsContainer({
  selectedMonth,
  goals = [],
  goalPriorities = [],
  goalMonthConfigs = [],
  transactions = [],
  budgetStartDate,
  excludedMonthsSet,
  lockedMonthsSet,
  getSignedAmountForTransaction,
  onSaveGoal,
  onDeleteGoal,
  onSetGoalStatus,
  onSetGoalModeForMonth,
  onSaveGoalAllocationsForMonth,
  onReorderGoalsForMonth,
  styles,
}: Props) {
  return (
    <FinancialGoalsPanel
      selectedMonth={selectedMonth}
      goals={goals}
      goalPriorities={goalPriorities}
      goalMonthConfigs={goalMonthConfigs}
      transactions={transactions}
      budgetStartDate={budgetStartDate}
      excludedMonthsSet={excludedMonthsSet}
      lockedMonthsSet={lockedMonthsSet}
      getSignedAmountForTransaction={getSignedAmountForTransaction}
      onSaveGoal={onSaveGoal}
      onDeleteGoal={onDeleteGoal}
      onSetGoalStatus={onSetGoalStatus}
      onSetGoalModeForMonth={onSetGoalModeForMonth}
      onSaveGoalAllocationsForMonth={onSaveGoalAllocationsForMonth}
      onReorderGoalsForMonth={onReorderGoalsForMonth}
      styles={styles}
    />
  )
}
